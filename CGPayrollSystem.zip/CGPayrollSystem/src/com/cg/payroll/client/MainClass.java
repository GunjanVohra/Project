package com.cg.payroll.client;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		
	   PayrollServices service=new PayrollServicesImpl();
	   int associateId=service.acceptAssociateDetails("Harsimran", "singh", "hsbgmail.com","gerre", "Intern", "7645hhsjs", 1323, 1233, 13213, 13213, 2565, "hbank", "citihh");
	   System.out.println("Associate id: "+associateId);
	   int associateId2=service.acceptAssociateDetails("Harsimran", "Singh Bedi", "hsb1497gmail", "development", "intern", "56sfyhy", 456, 676, 5425, 787, 6754, "bankname", "54fdfre");
	   System.out.println("Associate id: "+ associateId2);
	   
	   
	   try
	   {
		   System.out.println(service.getAssociateDetails(101));
		   
	   }catch(AssociateDetailsNotFoundException ae)
	   {
		   System.out.println(ae.getMessage());
	   }
	   
	   

}
}
