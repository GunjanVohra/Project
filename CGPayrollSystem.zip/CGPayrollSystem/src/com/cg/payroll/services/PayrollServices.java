package com.cg.payroll.services;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
public interface PayrollServices {

		int acceptAssociateDetails(String firstName,String lastName, String emailId,String department,String designation,String pancard,int yearlyInvestmentUnder80C,int basicSalary, int companyPf, int epf,int accountNumber, String bankName,String ifscCode);
		int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException;
		Associate getAssociateDetails(int associateId)throws AssociateDetailsNotFoundException;
		List<Associate>getAllAssociateDetails();
		//int acceptAssociateIdDetails(String string, String string2, String string3, String string4, String string5,
			//	int i, int j, int k, int l, int m, int n, String string6, int o);
		
		



}
